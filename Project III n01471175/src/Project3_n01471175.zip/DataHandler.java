//data handler interface
public abstract interface DataHandler 
{
	// getInfo and getFIle data 
	public abstract String getInfo();
	
	public abstract String getFileData();

}
